NETYS PRO - Android overlay starter project
Yêu cầu: Android Studio/AndroidIDE có Android SDK, JDK 17 và Gradle.
Build: gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk

Cách build không cần PC:
1. Tải ZIP và giải nén.
2. Tạo repository GitHub mới và tải toàn bộ nội dung project lên.
3. Mở tab Actions, chọn "Build NETYS PRO APK", nhấn Run workflow.
4. Khi chạy xong, mở workflow run và tải artifact NETYS-PRO-debug.

Lần đầu bật menu, cấp quyền "Hiển thị trên ứng dụng khác".
Muốn chỉnh độ sáng, cấp thêm quyền "Modify system settings".

Giới hạn: Overlay chỉ là bảng tiện ích Android. Nó không inject vào game, không sửa game,
không đảm bảo tăng FPS/ping và không thể điều khiển nội bộ mọi game.
