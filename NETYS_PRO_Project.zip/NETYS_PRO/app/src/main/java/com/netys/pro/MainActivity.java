package com.netys.pro;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    Spinner games;
    ArrayList<String> labels = new ArrayList<>();
    ArrayList<String> packages = new ArrayList<>();

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setPadding(dp(4),dp(8),dp(4),dp(8)); return t;
    }
    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(25,115,220)));
        return b;
    }
    public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(24),dp(20),dp(20));
        root.setBackgroundColor(Color.rgb(12,18,32));
        setContentView(root);
        root.addView(label("NETYS PRO",28));
        root.addView(label("Floating game tools • Android",14));
        root.addView(label("Chọn game muốn mở",16));
        games = new Spinner(this);
        loadGames();
        root.addView(games);
        Button launch = btn("MỞ GAME ĐÃ CHỌN");
        launch.setOnClickListener(v -> launchSelected());
        root.addView(launch);
        Button overlay = btn("BẬT MENU NỔI");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, FloatingMenuService.class));
                Toast.makeText(this,"Menu nổi đã bật",Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(overlay);
        Button brightness = btn("CẤP QUYỀN ĐIỀU CHỈNH ĐỘ SÁNG");
        brightness.setOnClickListener(v -> {
            if (!Settings.System.canWrite(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    android.net.Uri.parse("package:" + getPackageName())));
            else Toast.makeText(this,"Đã có quyền điều chỉnh độ sáng",Toast.LENGTH_SHORT).show();
        });
        root.addView(brightness);
        root.addView(label("Lưu ý: Android không cho phép ứng dụng này tự thay đổi mã, dữ liệu hoặc cơ chế hoạt động bên trong game khác.",13));
    }
    void loadGames() {
        android.content.pm.PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(query,0);
        Collections.sort(apps,(left,right)->left.loadLabel(pm).toString().compareToIgnoreCase(right.loadLabel(pm).toString()));
        for (android.content.pm.ResolveInfo r: apps) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName())) continue;
            labels.add(r.loadLabel(pm).toString()); packages.add(p);
        }
        if(labels.isEmpty()) labels.add("Không tìm thấy game");
        games.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));
    }
    void launchSelected() {
        int n=games.getSelectedItemPosition();
        if(n<0 || n>=packages.size()) return;
        Intent i=getPackageManager().getLaunchIntentForPackage(packages.get(n));
        if(i!=null) startActivity(i);
        else Toast.makeText(this,"Không mở được ứng dụng",Toast.LENGTH_SHORT).show();
    }
}
