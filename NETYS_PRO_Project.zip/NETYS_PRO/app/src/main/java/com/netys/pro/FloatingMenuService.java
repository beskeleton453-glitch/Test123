package com.netys.pro;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.*;
import android.view.Gravity;
import android.widget.*;

public class FloatingMenuService extends Service {
    WindowManager wm; View panel; WindowManager.LayoutParams params; boolean expanded=false;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    public IBinder onBind(Intent i){return null;}
    public void onCreate(){
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        showBubble();
    }
    TextView text(String s,int size){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);
        t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(8),dp(10),dp(8));return t;
    }
    WindowManager.LayoutParams layout(int w,int h){
        return new WindowManager.LayoutParams(w,h,Build.VERSION.SDK_INT>=26?
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
          PixelFormat.TRANSLUCENT);
    }
    void showBubble(){
        TextView bubble=text("N",18); bubble.setBackgroundColor(Color.rgb(0,115,235));
        params=layout(dp(54),dp(54));params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(8);params.y=dp(180);
        wm.addView(bubble,params);
        bubble.setOnTouchListener(new View.OnTouchListener(){
            float sx,sy;int ox,oy;long down;
            public boolean onTouch(View v,android.view.MotionEvent e){
                if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;down=System.currentTimeMillis();return true;}
                if(e.getAction()==1){if(Math.abs(e.getRawX()-sx)<dp(8)&&Math.abs(e.getRawY()-sy)<dp(8)) toggle();return true;}
                if(e.getAction()==2){params.x=ox+(int)(e.getRawX()-sx);params.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(bubble,params);return true;}
                return true;
            }
        });
        panel=bubble;
    }
    void toggle(){
        if(expanded){wm.removeView(panel);expanded=false;showBubble();return;}
        if(panel!=null)wm.removeView(panel);
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackgroundColor(Color.rgb(15,25,45));
        TextView title=text("NETYS PRO  •  GAME PANEL",16);box.addView(title);
        Button bright=new Button(this);bright.setText("Độ sáng hệ thống");bright.setAllCaps(false);
        bright.setOnClickListener(v->{
            if(Settings.System.canWrite(this)){
                int cur=Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,120);
                Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,Math.min(255,cur+25));
            } else {
                Intent i=new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);
            }
        });box.addView(bright);
        Button wifi=new Button(this);wifi.setText("Mở cài đặt mạng");wifi.setAllCaps(false);
        wifi.setOnClickListener(v->{Intent i=new Intent(Settings.ACTION_WIFI_SETTINGS);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});box.addView(wifi);
        Button close=new Button(this);close.setText("Thu nhỏ menu");close.setAllCaps(false);close.setOnClickListener(v->toggle());box.addView(close);
        params=layout(dp(250),WindowManager.LayoutParams.WRAP_CONTENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(8);params.y=dp(180);
        wm.addView(box,params);panel=box;expanded=true;
    }
    public void onDestroy(){super.onDestroy();if(panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}}
}
